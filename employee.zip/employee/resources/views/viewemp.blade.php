@extends('layouts.app')
@section('content')
<div class="card m-auto" style="width: 18rem; ">
  <img src="{{ asset ($empdetail->ekyc) }}" class="card-img-top text-center m-auto p-2 img img-responsive" alt="img" height="80px" style="width: 80px;">
  <div class="card-body">
    <h5 class="card-title text-center fw-bold"> {{ $empdetail->firstname }} {{ $empdetail->lastname }} </h5>
    <p><span class="fw-bold">Email :</span> {{ $empdetail->email }}</p>
    <p><span class="fw-bold">Address :</span> {{ $empdetail->address }}</p>
    <p class="card-text"><span class="fw-bold"> Registered At :</span> {{ $empdetail->created_at->format('d-m-Y') }}</p>
    <div class="text-center">
    <a href="/" class="btn btn-primary">Home</a>
    </div>
  </div>
</div>

@endsection