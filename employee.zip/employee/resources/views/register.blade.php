@extends('layouts.app')
@section('content')


<!-- @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->lastname as $error)
                <li>{{ $error}}</li>
            @endforeach
        </ul>
    </div>
@endif -->


<form action="{{route('store')}}" class="row g-3 col-4 m-auto bg-light p-3 border border-success rounded" method="POST" enctype="multipart/form-data">
  @csrf
    <div class="col-12">
        <label for="firstname" class="form-label">First Name</label>
        <input type="text" class="form-control" id="firstname" name="firstname" value="{{old('firstname')}}" style="border-color: {{ $errors->has('firstname') ? 'red' : 'green' }};">
          <span class="text-danger">
            @error('firstname')
              <small>{{ $message }}</small>
            @enderror
          </span>
    </div>
      <div class="col-12">
        <label for="lastname" class="form-label">Last Name</label>
        <input type="text" class="form-control" id="lastname" name="lastname" value="{{old('lastname')}}" style="border-color: {{ $errors->has('lastname') ? 'red' : 'green' }};">
        <span class="text-danger">
            @error('lastname')
              <small>{{ $message }}</small>
            @enderror
          </span>
      </div>
    <div class="col-md-12">
      <label for="email" class="form-label">Email</label>
      <input type="email" class="form-control" id="email" name="email" value="{{old('email')}}" style="border-color: {{ $errors->has('email') ? 'red' : 'green' }};">
      <span class="text-danger">
        @error('email')
          <small>{{ $message }}</small>
        @enderror
      </span>
      <span class="invalid-feedback">
          <strong>Error</strong>
        </span>
    </div>
    <div class="col-md-12">
      <label for="mobile" class="form-label">Mobile Number</label>
      <input type="number" class="form-control" id="mobile" name="mobilenumber" value="{{old('mobilenumber')}}" style="border-color: {{ $errors->has('mobilenumber') ? 'red' : 'green' }};">
        <span class="text-danger">
          @error('mobilenumber')
            <small>{{ $message }}</small>
          @enderror
        </span>
    </div>
    <div class="col-md-12">
      <label for="password" class="form-label">Password</label>
      <input type="password" class="form-control" id="password" name="password"  style="border-color: {{ $errors->has('password') ? 'red' : 'green' }};">
        <span class="text-danger">
          @error('password')
            <small>{{ $message }}</small>
          @enderror
        </span>
    </div>
    <div class="col-md-12">
        <label for="confirmpwd" class="form-label">Confirm Password</label>
        <input type="password" class="form-control" id="confirmpassword" name="confirmpassword"  style="border-color: {{ $errors->has('confirmpassword') ? 'red' : 'green' }};">
        <span class="text-danger">
          @error('confirmpassword')
            <small>{{ $message }}</small>
          @enderror
        </span>
      </div>    
    <div class="col-12">
      <label for="address" class="form-label">Address</label>
      <input type="text" class="form-control" id="address" placeholder="Apartment, studio, or floor" name="address" value="{{old('address')}}" style="border-color: {{ $errors->has('address') ? 'red' : 'green' }};">
        <span class="text-danger">
          @error('address')
            <small>{{ $message }}</small>
          @enderror
        </span>
    </div>
    <div class="col-md-12">
      <label for="gender" class="form-label">Gender</label>
      <div class="form-check form-check-inline ms-3">
        <input class="form-check-input" type="radio" name="gender" id="male" value="male" {{ old('gender') == 'male' ? 'checked' : '' }} style="border-color: {{ $errors->has('gender') ? 'red' : 'green' }};">
        <label class="form-check-label" for="male">Male</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="gender" id="female" value="female" {{ old('gender') == 'female' ? 'checked' : '' }} style="border-color: {{ $errors->has('gender') ? 'red' : 'green' }};">
        <label class="form-check-label" for="female">Female</label>
      </div><br/>
      <span class="text-danger invalid">
          @error('gender')
            <small>{{ $message }}</small>
          @enderror
        </span>
    </div>
    
    <div class="col-md-12">
        <label for="formFile" class="form-label">EKYC</label>
        <input class="form-control" type="file" id="ekyc" name="ekyc" style="border-color: {{ $errors->has('ekyc') ? 'red' : 'green' }};">
          <span class="text-danger">
            @error('ekyc')
              <small>{{ $message }}</small>
            @enderror
          </span>
    </div>
    <div class="col-12 d-flex justify-content-center">
      <button type="submit" class="btn btn-primary m-2">Sign Up</button>
      <a href="/" class="btn btn-danger m-2">Cancel</a>
    </div>
  </form>

  @endsection