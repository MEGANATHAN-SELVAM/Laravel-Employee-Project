@extends('layouts.app')
@section('content')

@if(session('message'))
    <div class="alert alert-success">
        {{ session('message') }}
    </div>
@endif


<div class="row">
    <div class="col-12">
        <h3 class="text-center text-white">Employees List</h3>
    </div>
    <div class="col mb-3">
        <h6 class="text-end"><a href="{{route('create')}}" class="text-white">Add New Employee</a></h6>
    </div>
</div>

<form action="{{route('search')}}" method="POST" class="mb-3 text-end">
@csrf
<div class="row align-items-end">
  <div class="col-3 d-flex">
    <input type="text" id="searchInput" placeholder="Search Name" name="searchdata" class="form-control form-control-sm">
    <button id="searchButton" type="submit" class="btn btn-primary ms-1">Search</button>
  </div>
</div>
</form>

<table class="table table-hover table-dark table-striped">
    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">FirstName</th>
        <th scope="col">LastName</th>
        <th scope="col">Email</th>
        <th scope="col">Mobile</th>
        <th scope="col">Address</th>
        <th scope="col">Gender</th>
        <th scope="col">EKYC</th>
        <th scope="col">Created At</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      @foreach ($employee as $employees)
      <tr>
        <th scope="row">{{ $employees->id }}</th>
        <td>{{$employees->firstname}}</td>
        <td>{{$employees->lastname}}</td>
        <td>{{$employees->email}}</td>
        <td>{{$employees->mobilenumber}}</td>
        <td>{{$employees->address}}</td>
        <td>{{$employees->gender}}</td>
        <td><img src="{{ asset ($employees->ekyc) }}" class="img img-responsive" width="30" height="30" /></td>
        <td>{{ $employees->created_at }} </td>
        <td>
            <a href="{{url('/viewemp/'.$employees->id)}}" class="badge bg-success text-white text-decoration-none">View</a>
            <a href="{{url('/edit/'.$employees->id)}}" class="badge bg-warning text-white text-decoration-none">Edit</a>
            <a href="{{ url('/destroy/'.$employees->id)}}" class="badge bg-danger text-decoration-none text-white">Delete</a>
        </td>
      </tr>    
               
      @endforeach

    </tbody>
  </table>
  <div class="pagination d-grid d-flex justify-content-end m-3 bg-transparent">
      <span class="text-primary badge"> {{ $employee->links() }} </span><!-- Display pagination links -->
  </div>


@endsection