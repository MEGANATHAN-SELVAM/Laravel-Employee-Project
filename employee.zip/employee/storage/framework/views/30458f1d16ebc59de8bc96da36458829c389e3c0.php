
<?php $__env->startSection('content'); ?>

<?php if(session('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?>


<div class="row">
    <div class="col-12">
        <h3 class="text-center text-white">Employees List</h3>
    </div>
    <div class="col mb-3">
        <h6 class="text-end"><a href="<?php echo e(route('create')); ?>" class="text-white">Add New Employee</a></h6>
    </div>
</div>

<form action="<?php echo e(route('search')); ?>" method="POST" class="mb-3 text-end">
<?php echo csrf_field(); ?>
<div class="row align-items-end">
  <div class="col-3 d-flex">
    <input type="text" id="searchInput" placeholder="Search Name" name="searchdata" class="form-control form-control-sm">
    <button id="searchButton" type="submit" class="btn btn-primary ms-1">Search</button>
  </div>
</div>
</form>

<table class="table table-hover table-dark table-striped">
    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">FirstName</th>
        <th scope="col">LastName</th>
        <th scope="col">Email</th>
        <th scope="col">Mobile</th>
        <th scope="col">Address</th>
        <th scope="col">Gender</th>
        <th scope="col">EKYC</th>
        <th scope="col">Created At</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($employees->id); ?></th>
        <td><?php echo e($employees->firstname); ?></td>
        <td><?php echo e($employees->lastname); ?></td>
        <td><?php echo e($employees->email); ?></td>
        <td><?php echo e($employees->mobilenumber); ?></td>
        <td><?php echo e($employees->address); ?></td>
        <td><?php echo e($employees->gender); ?></td>
        <td><img src="<?php echo e(asset ($employees->ekyc)); ?>" class="img img-responsive" width="30" height="30" /></td>
        <td><?php echo e($employees->created_at); ?> </td>
        <td>
            <a href="<?php echo e(url('/viewemp/'.$employees->id)); ?>" class="badge bg-success text-white text-decoration-none">View</a>
            <a href="<?php echo e(url('/edit/'.$employees->id)); ?>" class="badge bg-warning text-white text-decoration-none">Edit</a>
            <a href="<?php echo e(url('/destroy/'.$employees->id)); ?>" class="badge bg-danger text-decoration-none text-white">Delete</a>
        </td>
      </tr>    
               
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>
  <div class="pagination d-grid d-flex justify-content-end m-3 bg-transparent">
      <span class="text-primary badge"> <?php echo e($employee->links()); ?> </span><!-- Display pagination links -->
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel 10\employee\resources\views/index.blade.php ENDPATH**/ ?>