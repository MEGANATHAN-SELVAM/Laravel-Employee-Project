
<?php $__env->startSection('content'); ?>
<div class="card m-auto" style="width: 18rem; ">
  <img src="<?php echo e(asset ($empdetail->ekyc)); ?>" class="card-img-top text-center m-auto p-2 img img-responsive" alt="img" height="80px" style="width: 80px;">
  <div class="card-body">
    <h5 class="card-title text-center fw-bold"> <?php echo e($empdetail->firstname); ?> <?php echo e($empdetail->lastname); ?> </h5>
    <p><span class="fw-bold">Email :</span> <?php echo e($empdetail->email); ?></p>
    <p><span class="fw-bold">Address :</span> <?php echo e($empdetail->address); ?></p>
    <p class="card-text"><span class="fw-bold"> Registered At :</span> <?php echo e($empdetail->created_at->format('d-m-Y')); ?></p>
    <div class="text-center">
    <a href="/" class="btn btn-primary">Home</a>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel 10\employee\resources\views/viewemp.blade.php ENDPATH**/ ?>