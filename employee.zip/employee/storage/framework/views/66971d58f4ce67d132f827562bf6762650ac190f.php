
<?php $__env->startSection('content'); ?>

<!-- <?php if($errors): ?>
  <?php dd($errors->any); ?>
  <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger">
      <?php echo e($error); ?>

    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?> -->

<!-- <?php if(session('message')): ?>
  <div class="alert alert-danger"><?php echo e(session('message')); ?></div>
<?php endif; ?> -->

<form action="<?php echo e(route('store')); ?>" class="row g-3 col-4 m-auto bg-light p-3 border border-success rounded" method="POST" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
    <div class="col-12">
        <label for="firstname" class="form-label">First Name</label>
        <input type="text" class="form-control" id="firstname" name="firstname" value="">
        
        <!-- <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="text-danger">
            <?php echo e($message); ?>

          </span>  
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     -->
    </div>
      <div class="col-12">
        <label for="lastname" class="form-label">Last Name</label>
        <input type="text" class="form-control" id="lastname" name="lastname">
        <span class="invalid-feedback">
          <strong>Error</strong>
        </span>
      </div>
    <div class="col-md-12">
      <label for="email" class="form-label">Email</label>
      <input type="email" class="form-control" id="email" name="email">
      <span class="invalid-feedback">
          <strong>Error</strong>
        </span>
    </div>
    <div class="col-md-12">
      <label for="mobile" class="form-label">Mobile Number</label>
      <input type="number" class="form-control" id="mobile" name="mobilenumber">
      <span class="invalid-feedback">
          <strong>Error</strong>
        </span>
    </div>
    <div class="col-md-12">
      <label for="password" class="form-label">Password</label>
      <input type="password" class="form-control" id="password" name="password">
      <span class="invalid-feedback">
          <strong>Error</strong>
        </span>
    </div>
    <div class="col-md-12">
        <label for="confirmpwd" class="form-label">Confirm Password</label>
        <input type="password" class="form-control" id="confirmpassword" name="confirmpassword">
        <span class="invalid-feedback">
          <strong>Error</strong>
        </span>
      </div>    
    <div class="col-12">
      <label for="address" class="form-label">Address</label>
      <input type="text" class="form-control" id="address" placeholder="Apartment, studio, or floor" name="address">
      <span class="invalid-feedback">
          <strong>Error</strong>
        </span>
    </div>
    <div class="col-md-12">
      <label for="gender" class="form-label">Gender</label>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="gender" id="male" value="male">
        <label class="form-check-label" for="male">Male</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="gender" id="female" value="female">
        <label class="form-check-label" for="female">Female</label>
      </div>
    </div>
    <div class="col-md-12">
        <label for="formFile" class="form-label">EKYC</label>
        <input class="form-control" type="file" id="ekyc" name="ekyc">
        <span class="invalid-feedback">
          <strong>Error</strong>
        </span>
    </div>
    <div class="col-12 d-flex justify-content-center">
      <button type="submit" class="btn btn-primary m-2">Sign Up</button>
      <a href="/" class="btn btn-danger m-2">Cancel</a>
    </div>
  </form>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel 10\employee\resources\views//register.blade.php ENDPATH**/ ?>