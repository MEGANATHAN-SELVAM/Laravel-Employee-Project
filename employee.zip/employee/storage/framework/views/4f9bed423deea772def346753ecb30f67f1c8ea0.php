
<?php $__env->startSection('content'); ?>


<!-- <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->lastname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?> -->


<form action="<?php echo e(url('update', $edit->id)); ?>" class="row g-3 col-4 m-auto bg-light p-3 border border-success rounded" method="POST" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <?php echo method_field('PUT'); ?>

    <input type="hidden" value="$edit->id">

    <div class="col-12">
        <label for="firstname" class="form-label">First Name</label>
        <input type="text" class="form-control" id="firstname" name="firstname" value="<?php echo e($edit->firstname); ?>" style="border-color: <?php echo e($errors->has('firstname') ? 'red' : 'green'); ?>;">
          <span class="text-danger">
            <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <small><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </span>
    </div>
      <div class="col-12">
        <label for="lastname" class="form-label">Last Name</label>
        <input type="text" class="form-control" id="lastname" name="lastname" value="<?php echo e($edit->lastname); ?>" style="border-color: <?php echo e($errors->has('lastname') ? 'red' : 'green'); ?>;">
        <span class="text-danger">
            <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <small><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </span>
      </div>
     
      <input type="hidden" class="form-control" id="email" name="email" value="<?php echo e($edit->email); ?>">
    
    <div class="col-md-12">
      <label for="mobile" class="form-label">Mobile Number</label>
      <input type="number" class="form-control" id="mobile" name="mobilenumber" value="<?php echo e($edit->mobilenumber); ?>" style="border-color: <?php echo e($errors->has('mobilenumber') ? 'red' : 'green'); ?>;">
        <span class="text-danger">
          <?php $__errorArgs = ['mobilenumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small><?php echo e($message); ?></small>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </span>
    </div>
    
    <div class="col-12">
      <label for="address" class="form-label">Address</label>
      <input type="text" class="form-control" id="address" placeholder="Apartment, studio, or floor" name="address" value="<?php echo e($edit->address); ?>" style="border-color: <?php echo e($errors->has('address') ? 'red' : 'green'); ?>;">
        <span class="text-danger">
          <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small><?php echo e($message); ?></small>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </span>
    </div>
    <div class="col-md-12">
      <label for="gender" class="form-label">Gender</label>
      <div class="form-check form-check-inline ms-3">
        <input class="form-check-input" type="radio" name="gender" id="male" value="male" <?php echo e($edit->gender == 'male' ? 'checked' : ''); ?> style="border-color: <?php echo e($errors->has('gender') ? 'red' : 'green'); ?>;">
        <label class="form-check-label" for="male">Male</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="gender" id="female" value="female" <?php echo e($edit->gender == 'female' ? 'checked' : ''); ?> style="border-color: <?php echo e($errors->has('gender') ? 'red' : 'green'); ?>;">
        <label class="form-check-label" for="female">Female</label>
      </div><br/>
      <span class="text-danger invalid">
          <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small><?php echo e($message); ?></small>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </span>
    </div>
    
    <div class="col-md-12">
        <label for="formFile" class="form-label">EKYC</label><br/>
        <span class="d-flex"><img src="<?php echo e($edit->ekyc); ?>" alt="" srcset="" width="50px" class="p-1"></span><br/>
        <input class="form-control" type="file" id="ekyc" name="ekyc" value = "<?php echo e($edit->ekyc); ?>" style="border-color: <?php echo e($errors->has('ekyc') ? 'red' : 'green'); ?>;">
        
          <span class="text-danger">
            <?php $__errorArgs = ['ekyc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <small><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </span>
    </div>

      <input type="hidden" class="form-control" id="password" name="password"  value= "<?php echo e($edit->password); ?>">
      <input type="hidden" class="form-control" id="confirmpassword" name="confirmpassword" value="<?php echo e($edit->confirmpassword); ?>">
      
    <div class="col-12 d-flex justify-content-center">
      <button type="submit" class="btn btn-primary m-2">Update</button>
      <a href="/" class="btn btn-danger m-2">Cancel</a>
    </div>
  </form>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel 10\employee\resources\views/edit.blade.php ENDPATH**/ ?>