<?php

use App\Http\Controllers\EmployeeController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[EmployeeController::class,'index']);
Route::get('/create',[EmployeeController::class,'create'])->name('create');
Route::post('/store',[EmployeeController::class, 'store'])->name('store');
Route::get('/edit/{id}',[EmployeeController::class, 'edit'])->name('edit');
Route::put('/update/{id}',[EmployeeController::class, 'update'])->name('update');
Route::get('index',[EmployeeController::class, 'index'])->name('index');
Route::get('/destroy/{id}',[EmployeeController::class, 'destroy'])->name('destroy');
Route::get('/register',[EmployeeController::class, 'register']);
Route::get('/viewemp/{id}',[EmployeeController::class, 'viewemp'])->name('viewemp');
Route::get('/search',[EmployeeController::class, 'search'])->name('search');
Route::post('/search',[EmployeeController::class, 'search'])->name('search');