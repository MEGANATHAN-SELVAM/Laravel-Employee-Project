<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;
use Illuminate\Validation\Validator;
use Illuminate\Pagination\LengthAwarePaginator;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $employee = Employee::paginate(3);
        return view('index',['employee'=>$employee]);
    }

    public function viewemp(Request $request, $id)
    {
        $empdetails = Employee::find($id);
        return view ('viewemp', ['empdetail'=> $empdetails]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('register');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'firstname' => 'required',
            'lastname' => 'required',
            'email' => 'required|unique:employees,email',
            'mobilenumber'=> 'required|unique:employees,mobilenumber|digits:10|max:10',
            'password' => 'required|string|digits_between:6,12',
            'confirmpassword' => 'required|string|same:password',
            'address' => 'required',
            'gender' => 'required',
            'ekyc'  => 'required|mimes:gif,png,jpg,jpeg',
        ],[
            'firstname' => 'First name is required',
            'confirm_password.same' => 'The password confirmation does not match.',
        ]);


        $imgname = time().$request->file('ekyc')->getClientOriginalName();
        $path = $request->file('ekyc')->storeAs('images', $imgname, 'public');
        $imgpath = '/storage/'.$path;

        // $data = $request->except('_token');
        // Employee::create($data);

        $employee = new Employee;
        $employee->firstname = $request->firstname;
        $employee->lastname = $request->lastname;
        $employee->email = $request->email;
        $employee->mobilenumber = $request->mobilenumber;
        $employee->address = $request->address;
        $employee->gender = $request->gender;
        $employee->ekyc = $imgpath;
        $employee->password = $request->password;
        $employee->confirmpassword = $request->confirmpassword;

        $employee->save();

        return redirect()->route('index')->withMessage('Registration Successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $edit = Employee::find($id);
        return view ('edit', ['edit'=> $edit]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'firstname' => 'required',
            'lastname' => 'required',
            'email' => 'required|email|unique:employees,email,'.$request->id,
            'mobilenumber'=> 'required|digits:10|max:10',
            'address' => 'required',
            'gender' => 'required',
            'ekyc'  => 'mimes:gif,png,jpg,jpeg',
            'password' => 'required',
            'confirmpassword' => 'required',
        ],[
            'firstname' => 'First name is required',
        ]);

        $employee = new Employee;
        $employee->firstname = $request->firstname;
        $employee->lastname = $request->lastname;

        $employee = Employee::where('email', $request->email)->first();
        $employee->mobilenumber = $request->mobilenumber;
        $employee->address = $request->address;
        $employee->gender = $request->gender;
        $employee->password= $request->password;
        $employee->confirmpassword = $request->confirmpassword;
        
        if($request->hasFile('ekyc')){
        $imgname = time().$request->file('ekyc')->getClientOriginalName();
        $path = $request->file('ekyc')->storeAs('images', $imgname, 'public');
        $imgpath = '/storage/'.$path;
        $employee->ekyc = $imgpath;
        }
        
        $employee->save();

        return redirect()->route('index')->withMessage('Updated Successfully!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        Employee::where('id',$id)->delete();
        return redirect('index')->with('message', 'Record deleted Successfully!');
    }

    public function search(Request $request)
    {
        $search_data = $request->input('searchdata');
        $employee = Employee::where('firstname', 'like', '%' . $search_data . '%')->paginate(3);
        
        return view('/index', ['employee' => $employee]);
    }
}
