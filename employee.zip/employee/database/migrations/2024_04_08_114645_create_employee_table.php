<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employee', function (Blueprint $table) {
            $table->id();
            $table->string('firstname')->nullable(false);
            $table->string('lastname')->nullable(false);
            $table->string('email')->nullable(false);
            $table->integer('mobilenumber')->nullable(false);
            $table->string('password')->nullable(false);
            $table->string('confirmpassword')->nullable(false);
            $table->string('address')->nullable(false);
            $table->string('gender')->default(false);
            $table->string('ekyc')->nullable(false);
            $table->timestamps();
        });

        Schema::rename('employee','employees');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employee');
    }
};
